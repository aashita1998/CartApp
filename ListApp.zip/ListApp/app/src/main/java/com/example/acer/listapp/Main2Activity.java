package com.example.acer.listapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main2Activity extends AppCompatActivity {
Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12;
 EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        editText=findViewById(R.id.et);
        b1=findViewById(R.id.b1);
        b2=findViewById(R.id.b2);
        b3=findViewById(R.id.b3);
        b4=findViewById(R.id.b4);
        b5=findViewById(R.id.b5);
        b6=findViewById(R.id.b6);
        b7=findViewById(R.id.b7);
        b8=findViewById(R.id.b8);
        b9=findViewById(R.id.b9);
        b10=findViewById(R.id.b10);
        b11=findViewById(R.id.b11);
        b12=findViewById(R.id.b12);


    }


    public void onclick(View view) {
    Button b=(Button)view;
    String buttontext = b.getText().toString();
        Intent intent=new Intent(this,MainActivity.class);
        intent.putExtra("button",buttontext);
        setResult(RESULT_OK,intent);
        finish();
    }

    public void search(View view) {
    String s=editText.getText().toString();
        Uri suri=Uri.parse("geo:0,0?q=" + s);
        Intent i= new Intent(Intent.ACTION_VIEW, suri);
        startActivity(i);
    }
}
