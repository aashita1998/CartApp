package com.example.acer.listapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView tv[]=new TextView[20];
    int i=0, constant_g=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv[0]=(TextView) findViewById(R.id.tv1);
        tv[1]=(TextView) findViewById(R.id.tv2);
        tv[2]=(TextView) findViewById(R.id.tv3);
        tv[3]=(TextView) findViewById(R.id.tv4);
        tv[4]=(TextView) findViewById(R.id.tv5);
        tv[5]=(TextView) findViewById(R.id.tv6);
        tv[6]=(TextView) findViewById(R.id.tv7);
        tv[7]=(TextView) findViewById(R.id.tv8);
        tv[8]=(TextView) findViewById(R.id.tv9);
        tv[9]=(TextView) findViewById(R.id.tv10);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        String d=data.getExtras().getString("button");
       if(i<=9){
           tv[i++].setText(d);
       }
       else{
           Toast.makeText(this, "List is full", Toast.LENGTH_SHORT).show();
       }
    }

    public void add(View view) {
        Intent intent =new Intent(this,Main2Activity.class);
        startActivityForResult(intent,constant_g);
    }
}
